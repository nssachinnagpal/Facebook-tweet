package com.fbtwitter.app;

public class MyTweets {
	String tweet;
	String url;
	String username;
	String userid;
	Long visited_counter;
	String key;
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public Long getVisited_counter() {
		return visited_counter;
	}
	public void setVisited_counter(Long visited_counter) {
		this.visited_counter = visited_counter;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	
}
